<ul class="left-align no-margin">
   	<li><h5><a href="insertarIngresos.php">Ingresar ingresos</a></h5></li>
		<li><h5><a href="insertarEgresos.php">Ingresar egresos</a></h5></li>
		<li><h5><a href="listarIngresos.php">Ver ingresos</a></h5></li>
		<li><h5><a href="listarEgresos.php">Ver egresos</a></h5></li>
		<li><h5><a href="listarIngresosHistorico.php">Ver ingresos historicos</a></h5></li>
		<li><h5><a href="listarEgresosHistorico.php">Ver egresos historicos</a></h5></li>
		<li><h5><a href="caja.php">Caja</a></h5></li>
		<li><h5><a href="calcularTotal.php">Calcular total</a></h5></li>
		<li><h5><a href="ingresarCategorias.php">Ingresar categorias</a></h5></li>
		<li><h5><a href="eliminarCategorias.php">Eliminar categorias</a></h5></li>

</ul>

<h4 class="left-align">HISTORICOS</h4>
<ul class="left-align no-margin">
	
	<li><h5><a href="listarIngresosHistorico.php">Ver ingresos historicos</a></h5></li>
	<li><h5><a href="listarEgresosHistorico.php">Ver egresos historicos</a></h5></li>


</ul>