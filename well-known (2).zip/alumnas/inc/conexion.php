<?php
$conexion=mysqli_connect("162.255.162.75", "edbplata_rodrigo", "Javierjavier1990", "edbplata_alumnas");
$conexion2=mysqli_connect("162.255.162.75", "edbplata_rodrigo", "Javierjavier1990", "edbplata_cashflow");

?>