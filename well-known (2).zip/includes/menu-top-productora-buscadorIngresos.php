<header>
	<div class="row row1">
		<div class="col l2 m2">
				
			</div>
			<div class="col l8 m8">
				
			</div>
			<div class="col l2 m2">
				<div class="center-align"style="float:right">
						<a href="../index.php"><p style="">Cerrar Sesion</p></a>
				</div>
			</div>
	</div>
	<div class="row no-margin-bottom">
			<div class="col l2 m2">
				<a href="index.php" style="text-decoration:none;color:white"><h3>PRODUCTORA</h3></a>
			</div>
			<div class="col l8 m8">
				<form id="buscador">
					<input type="text" id="busqueda" name="busqueda" placeholder="Buscar por concepto" style="color:white;margin-left: 4%;" onKeyUp="buscarIngresos();" autocomplete="off">				 
				</form>
				<div id="resultadoBuscador">
				
				</div>
			</div>
			<div class="col l2 m2">
				<div class="center-align"style="float:right">
						<h2 style="">CASHFLOW</h2>
				</div>
			</div>
	</div>


</header>